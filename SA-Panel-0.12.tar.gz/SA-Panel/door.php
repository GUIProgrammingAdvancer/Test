<!DOCTYPE html>
<html>  
    <head>
        <meta charset="utf-8"/>
        <title>Smart Ass</title>
    </head>

    <body background="res/bg_small.png" style="text-align:center; width:320px; margin:0 auto">
        <p>
            <font size="6px">Login to Smart Ass</font>
        </p>
        
        <form name="loginForm" method="POST" action="faq.php" onSubmit="return InputCheck(this)">
            <p>
                <label for="username" class="label" style="display:inline-block;width:100px">User name:</label>
                <input type="text" name="userName" value="" /><br/>
            </p>
            <p>
                <label for="password" class="label" style="display:inline-block;width:100px">Password:</label>
                <input type="password" name="passWord" value="" /><br/>
            </p>
	    <?php 
		session_start();
                if($_SESSION['status']=='FAIL') {
                    echo "<p> <font style='color:red'> " . $_SESSION['msg'] . " </font></p>";
                } elseif ($_SESSION['status']=='SUCCESS') {
                    echo "<p> <font style='color:green'> " . $_SESSION['msg'] . " </font></p>";
                }
                session_destroy();
                session_unset();
            ?>
            <h>version 0.1 (20180613)</h>
            <input type="submit" name="logReq" value=" Login " style="display:inline-block;font-size:18px" />
        </form>
        
        <p style="text-align:left">
            <font size="5px"> Please note: </font>
        </p>
        <p style="text-align:justify"> 
            If your connection is not through SSL and HTTPS, 
            or your browser warns the SSL certificate is invalid,
            please stop logging in and contact admin ASAP.
        </p>
        <h>See below for more information.</h><br/><br/>
        <img src="res/login/safe.png" alt="safe login" /><br/>
        <img src="res/login/notsafe1.png" alt="not safe because no SSL" /><br/>
        <img src="res/login/notsafe2.png" alt="not safe because invalid certificate" /><br/>
    </body>
</html>

<?php
?>
