<?php
    session_start();
    if(!isset($_SESSION['username'])){
        //http_response_code(401);
        //die();
    }
    session_destroy();

    $db = new mysqli($System_Config['db_host'], $System_Config['db_username'], $System_Config['db_password'], $System_Config['db_database']);;
    if (!$db) {
        die('Could not connect: [' . $db->connect_errno . ']' . $db->connect_error);
    }else {
        //echo "Logged into database as server account.<br/>";
    }

    $username = $_SESSION['username'];
    $res = $db->query("select u, d, transfer_enable, port, passwd, enable, method, class_expire from user where user_name='$username' limit 1");
    if($res instanceof mysqli_result){
        if($res->num_rows > 0){
            //success
            $info = $res->fetch_assoc();
        } else {
            //failed
	    $_SESSION['status'] = "FAIL";
	    $_SESSION['msg'] = "Fetching data failed, please try again.";
            header("Location: door.php");
            die();
        }
    } else {
        //error
        http_response_code(500);
        die();
    }    
?>

<!DOCTYPE html>
<html>  
    <head>
        <meta charset="utf-8"/>
        <title>Smart Ass</title>
    </head>

    <body background="res/bg_small.png" style="text-align:center; width:400px; margin:0 auto">
      
    <p style='text-align:left'><font size=5px>Account info:</font></p>
    <p style='text-align:left'>
        <h>
            Status: 
            <?php 
                 $now = date("y-m-d h:i:s");
                 if (strtotime($now) > strtotime($info['class_expire']){
                      echo "<font style='color:red'> EXIPRED </font>";
	         } elseif ($info['enabled']=='1') {
                      echo "<font style='color:green'> OK </font>";
                 } else {
                      echo "<font style='color:red'> NOT ENABLED </font>";
                 }
	    ?>
	</h>
        <h> 
	    Usage: <?php echo round(($info['u']+$info['d'])/1024/1024/1024, 2); ?>
	    GB / <?php echo round(($info['transfer_enable'])/1024/1024/1024); ?> GB
        </h>
        <h>
        Expires in: <?php echo $info['class_expire']; ?>
        </h>
        <h>
        Port: <?php echo $info['port']; ?>, passwd: <?php echo $info['passwd']; ?>
        </h>
        <h>
        Crypto: <?php echo $info['method']; ?>
        </h>
    </p>

    <p style='text-align:left'><font size=5px>Server status:</font></p>
    <?php
        $res = $db->query("select id, name, server, status from ss_node limit 5");
        if($res instanceof mysqli_result){
            echo "<table border='1'>";
            echo "<tr><th> ID </th><th> Server Name </th><th> Host </th><th> Status </th></tr>";
            while($row = $res->fetch_assoc()){
                echo "<tr><td>" . $row['id'] . "</td>";
                echo "<td>" . $row['name'] . "</td>";
                echo "<td>" . $row['server'] . "</td>";
                $color = $row['status']=='Online'?'green':'black';
                echo "<td><font style='color:$color'>" . $row['status'] . "</font></td></tr>";
            }
            echo "</table>";
        } else {
            http_response_code(500);
            die();
        }
    ?>
    </body>
</html>

<?php

    

?>
