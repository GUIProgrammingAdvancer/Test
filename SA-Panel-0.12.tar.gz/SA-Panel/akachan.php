
<?php
    session_start();
    if(!isset($_SESSION['status'])){
        http_response_code(403);
        die();
    }
?>

<!DOCTYPE html>
<html>  
    <head>
        <meta charset="utf-8"/>
        <title>Smart Ass</title>
    </head>

    <body background="res/bg_small.png" style="text-align:center; width:320px; margin:0 auto">
        <p>
            <font size="6px">Smart Ass Register</font>
        </p>
        
        <form name="regForm" method="POST" action="faq.php" onSubmit="return InputCheck(this)">
            <p>
                <label for="username" class="label" style="display:inline-block;width:100px">User name:</label>
                <input type="text" name="userName" value="" /><br/>
            </p>
            <p>
                <label for="mailaddress" class="label" style="display:inline-block;width:100px">E-mail:</label>
                <input type="text" name="mailBox" value="" /><br/>
            </p>
            <p>
                <label for="password" class="label" style="display:inline-block;width:100px">Password:</label>
                <input type="password" name="passWord" value="" /><br/>
            </p>
            <p>
                <label for="repassword" class="label" style="display:inline-block;width:100px">Repeat PW:</label>
                <input type="password" name="rePw" value="" /><br/>
            </p>        
            
            <p style="text-align:left">
                <font size="5px"> Keep in mind: </font>
            </p>
            <p style="text-align:justify"> 
                This site is not safe. No one can promise that the 
                information you input is safe. NEVER use any password
                that you are using on other websites!
            </p>
            
            <input type="submit" name="regReq" value=" Register / Change Password " style="display:inline-block;font-size:18px" />
            
            <?php 
                if($_SESSION['status']=='FAIL') {
                    echo "<p> <font style='color:red'> " . $_SESSION['msg'] . " </font></p>";
                } elseif ($_SESSION['status']=='SUCCESS') {
                    echo "<p> <font style='color:green'> " . $_SESSION['msg'] . " </font></p>";
                }
                session_destroy();
                session_unset();
            ?>
        </form>

    </body>
</html>
