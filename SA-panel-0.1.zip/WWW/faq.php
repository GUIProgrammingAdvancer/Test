<?php
    $db = new mysqli('localhost', 'server', '666666', 'test');
    if (!$db) {
        http_response_code(500);
        die();
    }

    session_start();
    $RANDOM = "rtz$PT!rnt8st5B9^nb7GFd5zM9n#v5TN9mS4Y%yvM^sN%Jn2t
            2eZtK@MCRpn%h@!5KXxxq*p7!KMMGjJdgAYTS58*H6E9@ur2qd$qYe%R7tHyV*bpR7ukS&rxvJ%2HSG7agqY
            DPgESrf*CW8UrecJ4Bv8jP65qc$^SrcvE87#8RVuDBNz3^b7qKDWeaB$XqJFb5*P#R";

    if(isset($_POST['logReq'])){
        $username = htmlspecialchars($_POST['userName']);
        $password = MD5($_POST['passWord'] . $RANDOM . $_POST["username"]);
        //echo "Acc is " . $username . " and pw is " . $password . "<br/>";

        if($username == "register"){
            $_SESSION['status'] = "reg";
            header("Location: akachan.php");
            die();
        }

        $res = $db->query("select id from user where user_name='$username' and pass='$password' limit 1");
        if($res instanceof mysqli_result){
            if($res->num_rows > 0){
                //success
                //echo $res->num_rows . " records found.<br/>";
                $row = $res->fetch_assoc();
                $_SESSION['username'] = $username;
                $_SESSION['userid'] = $row['id'];
                $res->close();
                header("Location: gym.php");
                die();
            } else {
                //failed
                http_response_code(401);
                die();
            }
        } else {
            //error
            http_response_code(500);
            die();
        }
        
        
        
    } elseif (isset($_POST['regReq'])) {
        if($_POST['passWord'] != $_POST['rePw']) {
            $_SESSION['status'] = "ERROR";
            $_SESSION['errMsg'] = "Two passwords are not same!";
            header("Location: akachan.php");
            die();
        } 
        
        $username = htmlspecialchars($_POST['userName']);
        $res = $db->query("select id from user where user_name='$username' limit 1");
        if($res instanceof mysqli_result){
            if($res->num_rows > 0){
                //already registered
                $_SESSION['status'] = "ERROR";
                $_SESSION['errMsg'] = "Username already registered!";
                $res->close();
                header("Location: akachan.php");
                die();
            }
        } else {
            //error
            http_response_code(500);
            die();
        }
        
        $mailbox = htmlspecialchars($_POST['mailBox']);
        $password = MD5($_POST['passWord'] . $RANDOM . $_POST["username"]);
        //echo "Acc is " . $username . " and pw is " . $password . "<br/>";

        $res = $db->query("insert into user(user_name, email, pass) 
                            values('$username', '$mailbox', '$password')");
        if($res){
            $_SESSION['status'] = "SUCCESS";
            $_SESSION['errMsg'] = "Successfully registered!";
            header("Location: akachan.php");
            die();
        } else {
            //error
            http_response_code(500);
            die();
        }
    } else {
        //illegal visit
        http_response_code(403);
        die();
    }

?>