<?php  
    header("Location: door.php");
    die();
?>