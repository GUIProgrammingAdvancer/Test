<?php
    $db = new mysqli($System_Config['db_host'], $System_Config['db_username'], $System_Config['db_password'], $System_Config['db_database']);
    if (!$db) {
        http_response_code(500);
        die();
    }

    session_start();

    if(isset($_POST['logReq'])){
	//login attempt
	if($_POST['userName'] == "") {
            $_SESSION['status'] = "FAIL";
            $_SESSION['msg'] = "Username cannot be empty!";
            header("Location: akachan.php");
            die();
	}

        $username = htmlspecialchars($_POST['userName']);
        $password = MD5($_POST['passWord'] . $System_Config['key'] . $_POST["username"]);

        if($username == "register"){
            $_SESSION['status'] = "reg";
            header("Location: akachan.php");
            die();
        }

        $res = $db->query("select id from user where user_name='$username' and pass='$password' limit 1");
        if($res instanceof mysqli_result){
            if($res->num_rows > 0){
                //success
                //echo $res->num_rows . " records found.<br/>";
                $row = $res->fetch_assoc();
                $_SESSION['username'] = $username;
                $_SESSION['userid'] = $row['id'];
                $res->close();
                header("Location: gym.php");
                die();
            } else {
                //failed
		$_SESSION['status'] = "failed";
		$_SESSION['msg'] = "Login failed, please try again.";
                die();
            }
        } else {
            //error
            http_response_code(500);
            die();
        }
        
        
        
    } elseif (isset($_POST['regReq'])) {
	//registeration
	if($_POST['userName'] == "" or $_POST['mailBox'] == ""
		or $_POST['passWord'] == "") {
            $_SESSION['status'] = "FAIL";
            $_SESSION['msg'] = "Blanks cannot be left empty!";
            header("Location: akachan.php");
            die();
	}

        if($_POST['passWord'] != $_POST['rePw']) {
            $_SESSION['status'] = "FAIL";
            $_SESSION['errMsg'] = "Two passwords are not same!";
            header("Location: akachan.php");
            die();
        } 
        
        $username = htmlspecialchars($_POST['userName']);
        $res = $db->query("select id from user where user_name='$username' limit 1");
        if($res instanceof mysqli_result){
            if($res->num_rows > 0){
                //already registered
                $_SESSION['status'] = "FAIL";
                $_SESSION['msg'] = "Username already registered!";
                $res->close();
                header("Location: akachan.php");
                die();
            }
        } else {
            //error
            http_response_code(500);
            die();
        }
        
        $mailbox = htmlspecialchars($_POST['mailBox']);
        $password = MD5($_POST['passWord'] . $System_Config['key'] . $_POST["username"]);
        //echo "Acc is " . $username . " and pw is " . $password . "<br/>";

        $res = $db->query("insert into user(user_name, email, pass) 
                            values('$username', '$mailbox', '$password')");
        if($res){
            $_SESSION['status'] = "SUCCESS";
            $_SESSION['msg'] = "Successfully registered!";
            header("Location: akachan.php");
            die();
        } else {
            //error
            http_response_code(500);
            die();
        }
    } else {
        //illegal visit
        http_response_code(403);
        die();
    }

?>
