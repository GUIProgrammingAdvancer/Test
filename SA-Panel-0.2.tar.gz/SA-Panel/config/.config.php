<?php

//SA panel configuration
$System_Config['key'] = '"rtz$PT!rnt8st5B9^nb7GFd5zM9n#v5TN9mS4Y%yvM^sN%Jn2t2eZtK@MCRpn%h@!5KXxxq*p7!KMMGjJdgAYTS58*H6E9@ur2qd$qYe%R7tHyV*bpR7ukS&rxvJ%2HSG7agqYDPgESrf*CW8UrecJ4Bv8jP65qc$^SrcvE87#8RVuDBNz3^b7qKDWeaB$XqJFb5*P#R"';

# database configuration
$System_Config['db_host'] = 'localhost';
$System_Config['db_database'] = 'panel';
$System_Config['db_username'] = 'server';
$System_Config['db_password'] = '666666';

?>

