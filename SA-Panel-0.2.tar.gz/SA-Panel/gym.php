<?php
    session_start();
    if(!isset($_SESSION['username'])){
        //http_response_code(401);
        //die();
    }
    session_destroy();

    $db = new mysqli($System_Config['db_host'], $System_Config['db_username'], $System_Config['db_password'], $System_Config['db_database']);;
    if (!$db) {
        die('Could not connect: [' . $db->connect_errno . ']' . $db->connect_error);
    }else {
        //echo "Logged into database as server account.<br/>";
    }
?>

<!DOCTYPE html>
<html>  
    <head>
        <meta charset="utf-8"/>
        <title>Smart Ass</title>
    </head>

    <body background="res/bg_small.png" style="text-align:center; width:400px; margin:0 auto">
      
    <p style='text-align:left'><font size=5px>Server status:</font></p>
    <?php
        $res = $db->query("select id, name, server, status from ss_node limit 5");
        if($res instanceof mysqli_result){
            echo "<table border='1'>";
            echo "<tr><th> ID </th><th> Server Name </th><th> Host </th><th> Status </th></tr>";
            while($row = $res->fetch_assoc()){
                echo "<tr><td>" . $row['id'] . "</td>";
                echo "<td>" . $row['name'] . "</td>";
                echo "<td>" . $row['server'] . "</td>";
                $color = $row['status']=='Online'?'green':'black';
                echo "<td><font style='color:$color'>" . $row['status'] . "</font></td></tr>";
            }
            echo "</table>";
        } else {
            http_response_code(500);
            die();
        }
    ?>
    </body>
</html>

<?php

    

?>
