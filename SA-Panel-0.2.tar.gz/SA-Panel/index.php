<?php  
    request("Location: config/.config.php");
    header("Location: door.php");
    die();
?>
